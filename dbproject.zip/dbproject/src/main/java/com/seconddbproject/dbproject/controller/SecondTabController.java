package com.seconddbproject.dbproject.controller;


import com.seconddbproject.dbproject.impl.SecondTabImpl;
import com.seconddbproject.dbproject.model.SecondTab;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.xml.ws.RequestWrapper;
import java.util.List;

@RestController
public class SecondTabController {

    @Autowired
    SecondTabImpl secondTabImpl;

    @RequestMapping(value = "/savedata")
    public String datasave(@RequestBody SecondTab secondTab) {
        secondTabImpl.saveData(secondTab);
        return "data saved successfully";
    }

    @RequestMapping(value = "/getdata")
    public List<SecondTab> getdata(){
        List<SecondTab> list = secondTabImpl.getList();
        System.out.println(list);
        return list;
    }

    @RequestMapping(value = "/getSingleRecord/{id}")
    public SecondTab getSingleRecord(@PathVariable Integer id){
        SecondTab st = secondTabImpl.getSingleRecord(id);
        return st;
    }

    @RequestMapping(value = "/updateData/{id}/{name}")
    public String updateData( @PathVariable Integer id, @PathVariable String name){
        secondTabImpl.updateData(id, name);
        return "Done!!";
    }
    @RequestMapping(value = "/deleteData/{id}")
    public String deleteData(@PathVariable Integer id){
        secondTabImpl.deleteData(id);
        return "Deleted!!";
    }
}
