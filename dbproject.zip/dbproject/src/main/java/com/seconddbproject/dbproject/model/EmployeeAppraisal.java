package com.seconddbproject.dbproject.model;

public class EmployeeAppraisal {
    Integer emp_id;
    String kra1;
    Integer kra1Weightage;
    Integer kra1Status;
    String kra2;
    Integer kra2Weightage;
    Integer kra2Status;
    String kra3;
    Integer kra3Weightage;
    Integer kra3Status;
    String kra4;
    Integer kra4Weightage;
    Integer kra4Status;
    Integer interpersonalSkills;
    Integer development;
    Integer codeOfConduct;
    Integer communicationSkills;
    Integer personality;
    Integer leadership;
    Integer numberOfRedFlags;

    public EmployeeAppraisal() {
    }

    public EmployeeAppraisal(Integer emp_id,
                             String kra1, Integer kra1Weightage, Integer kra1Status,
                             String kra2, Integer kra2Weightage, Integer kra2Status,
                             String kra3, Integer kra3Weightage, Integer kra3Status,
                             String kra4, Integer kra4Weightage, Integer kra4Status,
                             Integer interpersonalSkills, Integer development, Integer codeOfConduct,
                             Integer communicationSkills, Integer personality, Integer leadership,
                             Integer numberOfRedFlags) {
        this.emp_id = emp_id;
        this.kra1 = kra1;
        this.kra1Weightage = kra1Weightage;
        this.kra1Status = kra1Status;
        this.kra2 = kra2;
        this.kra2Weightage = kra2Weightage;
        this.kra2Status = kra2Status;
        this.kra3 = kra3;
        this.kra3Weightage = kra3Weightage;
        this.kra3Status = kra3Status;
        this.kra4 = kra4;
        this.kra4Weightage = kra4Weightage;
        this.kra4Status = kra4Status;
        this.interpersonalSkills = interpersonalSkills;
        this.development = development;
        this.codeOfConduct = codeOfConduct;
        this.communicationSkills = communicationSkills;
        this.personality = personality;
        this.leadership = leadership;
        this.numberOfRedFlags = numberOfRedFlags;
    }

    public Integer getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(Integer emp_id) {
        this.emp_id = emp_id;
    }

    public String getKra1() {
        return kra1;
    }

    public void setKra1(String kra1) {
        this.kra1 = kra1;
    }

    public Integer getKra1Weightage() {
        return kra1Weightage;
    }

    public void setKra1Weightage(Integer kra1Weightage) {
        this.kra1Weightage = kra1Weightage;
    }

    public Integer getKra1Status() {
        return kra1Status;
    }

    public void setKra1Status(Integer kra1Status) {
        this.kra1Status = kra1Status;
    }

    public String getKra2() {
        return kra2;
    }

    public void setKra2(String kra2) {
        this.kra2 = kra2;
    }

    public Integer getKra2Weightage() {
        return kra2Weightage;
    }

    public void setKra2Weightage(Integer kra2Weightage) {
        this.kra2Weightage = kra2Weightage;
    }

    public Integer getKra2Status() {
        return kra2Status;
    }

    public void setKra2Status(Integer kra2Status) {
        this.kra2Status = kra2Status;
    }

    public String getKra3() {
        return kra3;
    }

    public void setKra3(String kra3) {
        this.kra3 = kra3;
    }

    public Integer getKra3Weightage() {
        return kra3Weightage;
    }

    public void setKra3Weightage(Integer kra3Weightage) {
        this.kra3Weightage = kra3Weightage;
    }

    public Integer getKra3Status() {
        return kra3Status;
    }

    public void setKra3Status(Integer kra3Status) {
        this.kra3Status = kra3Status;
    }

    public String getKra4() {
        return kra4;
    }

    public void setKra4(String kra4) {
        this.kra4 = kra4;
    }

    public Integer getKra4Weightage() {
        return kra4Weightage;
    }

    public void setKra4Weightage(Integer kra4Weightage) {
        this.kra4Weightage = kra4Weightage;
    }

    public Integer getKra4Status() {
        return kra4Status;
    }

    public void setKra4Status(Integer kra4Status) {
        this.kra4Status = kra4Status;
    }

    public Integer getInterpersonalSkills() {
        return interpersonalSkills;
    }

    public void setInterpersonalSkills(Integer interpersonalSkills) {
        this.interpersonalSkills = interpersonalSkills;
    }

    public Integer getDevelopment() {
        return development;
    }

    public void setDevelopment(Integer development) {
        this.development = development;
    }

    public Integer getCodeOfConduct() {
        return codeOfConduct;
    }

    public void setCodeOfConduct(Integer codeOfConduct) {
        this.codeOfConduct = codeOfConduct;
    }

    public Integer getCommunicationSkills() {
        return communicationSkills;
    }

    public void setCommunicationSkills(Integer communicationSkills) {
        this.communicationSkills = communicationSkills;
    }

    public Integer getPersonality() {
        return personality;
    }

    public void setPersonality(Integer personality) {
        this.personality = personality;
    }

    public Integer getLeadership() {
        return leadership;
    }

    public void setLeadership(Integer leadership) {
        this.leadership = leadership;
    }

    public Integer getNumberOfRedFlags() {
        return numberOfRedFlags;
    }

    public void setNumberOfRedFlags(Integer numberOfRedFlags) {
        this.numberOfRedFlags = numberOfRedFlags;
    }
}
