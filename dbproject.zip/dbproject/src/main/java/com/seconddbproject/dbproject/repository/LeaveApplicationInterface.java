package com.seconddbproject.dbproject.repository;

import com.seconddbproject.dbproject.middleware.LeaveApplication;
import com.seconddbproject.dbproject.model.LeaveRecords;

import java.util.List;

public interface LeaveApplicationInterface {

    void leaveRequest(LeaveApplication leaveApplication);
    void leaveApproval(Integer leaveId);
    void leaveRejection(Integer leaveId);
    List<LeaveRecords> getAllLeaveApplications(Integer managerId);
    LeaveRecords getLeaveApplication(Integer leaveId);
    void LeaveCancellation(Integer leaveId);
    Integer getNumberOfCasualLeaves(Integer employeeId);
    Integer getNumberOfSickLeaves(Integer employeeId);
    Integer getNumberOfTotalLeaves(Integer employeeId);
    Integer getNumberOfOtherLeaves(Integer employeeId);
    List<LeaveRecords> getLeaveHistory(Integer employeeId);
    
}
