package com.seconddbproject.dbproject.model;

import com.seconddbproject.dbproject.middleware.LoginDetails;


public class LoginMaster extends LoginDetails {

    Integer emp_id;

    public LoginMaster() {
    }

    public LoginMaster(Integer emp_id) {
        this.emp_id = emp_id;
    }

    public Integer getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(Integer emp_id) {
        this.emp_id = emp_id;
    }
}

