package com.seconddbproject.dbproject.repository;

import com.seconddbproject.dbproject.model.SecondTab;
import org.springframework.stereotype.Repository;

import java.util.List;


public interface SecondTabInterface {

    void saveData(SecondTab secondTab);
    List<SecondTab> getList();
    SecondTab getSingleRecord(Integer id);
    void updateData(Integer id, String name);
    void deleteData(Integer id);
  }
