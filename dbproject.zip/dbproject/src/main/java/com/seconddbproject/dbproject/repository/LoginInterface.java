package com.seconddbproject.dbproject.repository;

import com.seconddbproject.dbproject.DTO.Response;
import com.seconddbproject.dbproject.middleware.LoginDetails;

public interface LoginInterface {

    Response login(LoginDetails loginDetails);
}
