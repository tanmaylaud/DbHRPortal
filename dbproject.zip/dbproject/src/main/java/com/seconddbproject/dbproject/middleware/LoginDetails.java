package com.seconddbproject.dbproject.middleware;

public class LoginDetails {
    String emp_userid;
    String emp_password;

    public LoginDetails() {
    }

    public LoginDetails(String emp_userid, String emp_password) {
        this.emp_userid = emp_userid;
        this.emp_password = emp_password;
    }

    public String getEmp_userid() {
        return emp_userid;
    }

    public void setEmp_userid(String emp_userid) {
        this.emp_userid = emp_userid;
    }

    public String getEmp_password() {
        return emp_password;
    }

    public void setEmp_password(String emp_password) {
        this.emp_password = emp_password;
    }
}
