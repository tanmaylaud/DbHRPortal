package com.seconddbproject.dbproject.impl;

import com.seconddbproject.dbproject.middleware.EnrolledCourses;
import com.seconddbproject.dbproject.model.Course;
import com.seconddbproject.dbproject.model.EmployeeTraining;
import com.seconddbproject.dbproject.repository.TrainingInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

@Repository
public class TrainingImpl implements TrainingInterface {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public List<EnrolledCourses> getListOfCourses(Integer employeeId) {
        String sql = "select * from employee_training where emp_id= ?";
        List<EmployeeTraining> list = jdbcTemplate.query(sql,
                new Object[]{employeeId},
                new BeanPropertyRowMapper(EmployeeTraining.class));
        List<EnrolledCourses> enrolledCourses = new ArrayList<EnrolledCourses>();
        List<Course> courses = getCourses();
        for (EmployeeTraining empt: list   ) {
            for (Course crs: courses ) {
                if(empt.getCourseId()==crs.getCourseId()){
                    EnrolledCourses ec = new EnrolledCourses(empt.getCourseId(),
                            empt.getEmp_id(),
                            empt.getCourseType(),
                            empt.getDueDate(),
                            empt.getCourseStatus(),
                            crs.getCourseName());
                    enrolledCourses.add(ec);
                }

            }

        }

        return enrolledCourses;
    }

    @Override
    public List<EnrolledCourses> updateCourseStatus(Integer courseId, Integer employeeId) {
        String sql = "update employee_training set course_status = ? where course_id =? and emp_id = ? ";
        jdbcTemplate.update(sql,
                new Object[]{"in progress", courseId, employeeId},
                new int[]{Types.VARCHAR, Types.INTEGER,Types.INTEGER});
        return getListOfCourses(employeeId);


    }

    public List<Course> getCourses(){
        String sql = "select * from course_list";
        return jdbcTemplate.query(sql,
                new BeanPropertyRowMapper(Course.class));
    }
}
