package com.seconddbproject.dbproject.model;

import java.util.Date;

public class EmployeeTraining {
    Integer courseId;
    Integer emp_id;
    String courseType;
    Date dueDate;
    String courseStatus;


    public EmployeeTraining() {
    }

    public EmployeeTraining(Integer courseId, Integer employeeId, String courseType, Date dueDate, String courseStatus) {
        this.courseId = courseId;
        this.emp_id = employeeId;
        this.courseType = courseType;
        this.dueDate = dueDate;
        this.courseStatus = courseStatus;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(Integer emp_id) {
        this.emp_id = emp_id;
    }

    public String getCourseType() {
        return courseType;
    }

    public void setCourseType(String courseType) {
        this.courseType = courseType;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public String getCourseStatus() {
        return courseStatus;
    }

    public void setCourseStatus(String courseStatus) {
        this.courseStatus = courseStatus;
    }
}
