package com.seconddbproject.dbproject.impl;

import com.seconddbproject.dbproject.DTO.Response;
import com.seconddbproject.dbproject.middleware.EmployeeDetailsDTO;
import com.seconddbproject.dbproject.middleware.LoginDetails;
import com.seconddbproject.dbproject.model.EmployeeMaster;
import com.seconddbproject.dbproject.model.LoginMaster;
import com.seconddbproject.dbproject.repository.LoginInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class LoginImpl implements LoginInterface {

    @Autowired
    JdbcTemplate jdbcTemplate;


    public Response loginpurana(LoginDetails loginDetails) {
        String sql = "select emp_id from login_master where emp_userid = ? and emp_password = MD5( ? )";
        try{
            Integer emp_id = jdbcTemplate.queryForObject(sql,
                    new Object[]{loginDetails.getEmp_userid(),loginDetails.getEmp_password()},
                    Integer.class);
            return new Response(201,new Object[]{emp_id});
        }
        catch(Exception e){
            return new Response(403,null);
        }
    }

    @Override
    public Response login(LoginDetails loginDetails){
        String sql = "select emp_id from login_master where emp_userid = ? and emp_password = MD5( ? )";
        try {
            Integer emp_id = jdbcTemplate.queryForObject(sql,
                    new Object[]{loginDetails.getEmp_userid(), loginDetails.getEmp_password()},
                    Integer.class);

            sql = "select * from employee_master where emp_id = ?";
            EmployeeMaster employeeMaster = jdbcTemplate.queryForObject(sql,
                    new Object[]{emp_id},
                    new BeanPropertyRowMapper<>(EmployeeMaster.class));
            sql = "select count(*) from employee_master where manager_id=?";
            Integer numberOfEmployees = jdbcTemplate.queryForObject(sql,
                    new Object[]{emp_id},
                    Integer.class);
            if (numberOfEmployees > 0) {
                sql = "select * from employee_master where manager_id=?";
                List<EmployeeMaster> employeees = jdbcTemplate.query(sql,
                        new Object[]{emp_id},
                        new BeanPropertyRowMapper(EmployeeMaster.class));
                EmployeeDetailsDTO employeeDetailsDTO = new EmployeeDetailsDTO(employeeMaster, true, employeees);
                return new Response(201,employeeDetailsDTO);
            } else {
                EmployeeDetailsDTO employeeDetailsDTO = new EmployeeDetailsDTO(employeeMaster, false, null);
                return new Response(201,employeeDetailsDTO);
            }


        }
        catch(Exception e){
            return new Response(403,null);
        }

    }
}
