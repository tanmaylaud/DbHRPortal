package com.seconddbproject.dbproject.middleware;

import com.seconddbproject.dbproject.model.EmployeeTraining;

import java.util.Date;

public class EnrolledCourses extends EmployeeTraining {
    String courseName;
    public EnrolledCourses(){

    }
    public EnrolledCourses(Integer courseId, Integer employeeId, String courseType, Date dueDate, String courseStatus, String courseName) {
        super(courseId, employeeId, courseType, dueDate, courseStatus);
        this.courseName = courseName;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}
