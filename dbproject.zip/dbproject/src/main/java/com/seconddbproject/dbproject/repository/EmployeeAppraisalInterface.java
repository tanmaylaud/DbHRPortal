package com.seconddbproject.dbproject.repository;

import com.seconddbproject.dbproject.DTO.Response;
import com.seconddbproject.dbproject.model.EmployeeAppraisal;

public interface EmployeeAppraisalInterface {
    EmployeeAppraisal getEmployeeAppraisal(Integer employeeId);
    long getEmployeeRating(Integer employeeId);
}
