package com.seconddbproject.dbproject.controller;

import com.seconddbproject.dbproject.impl.TrainingImpl;
import com.seconddbproject.dbproject.middleware.EnrolledCourses;
import com.seconddbproject.dbproject.model.EmployeeMaster;
import com.seconddbproject.dbproject.model.EmployeeTraining;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TrainingController {

    @Autowired
    TrainingImpl trainingImpl;

    @RequestMapping(value  = "/getlistofcourses/{employeeId}")
    List<EnrolledCourses> getListOfCourses(@PathVariable Integer employeeId){
        return trainingImpl.getListOfCourses(employeeId);
    }
    @RequestMapping(value ="/updatecoursestatus/{courseId}/{employeeId}")
    List<EnrolledCourses> updateCourseStatus(@PathVariable Integer courseId, @PathVariable Integer employeeId){
        return trainingImpl.updateCourseStatus(courseId,employeeId);

    }
}
