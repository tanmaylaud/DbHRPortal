package com.seconddbproject.dbproject.controller;

import com.seconddbproject.dbproject.impl.LeaveApplicationImpl;
import com.seconddbproject.dbproject.middleware.LeaveApplication;
import com.seconddbproject.dbproject.model.LeaveRecords;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class LeaveApplicationController {

    @Autowired
    LeaveApplicationImpl leaveApplicationImpl;

    @CrossOrigin(allowedHeaders = {"Origin","X-Requested-With","Content-Type","Accept","Authorization"},
            methods = {RequestMethod.GET,RequestMethod.DELETE,RequestMethod.POST,RequestMethod.PUT})
    @RequestMapping(value = "/leaverequest")
    public Boolean leaveRequest(@RequestBody LeaveApplication leaveApplication) {
        leaveApplicationImpl.leaveRequest(leaveApplication);
        return true;
    }

    @RequestMapping(value = "/leaveapproval/{leaveId}")
    public String leaveApproval(@PathVariable Integer leaveId){
        leaveApplicationImpl.leaveApproval(leaveId);
        return "Leave Approved";
    }

    @RequestMapping(value = "/leaverejection/{leaveId}")
    public String leaveRejection(@PathVariable Integer leaveId){
        leaveApplicationImpl.leaveRejection(leaveId);
        return "Leave Rejected";
    }

    @RequestMapping(value="/getallleaveapplicationsformanager/{managerId}")
    public List<LeaveRecords> getAllLeaveApplications(@PathVariable Integer managerId ){
        return leaveApplicationImpl.getAllLeaveApplications(managerId);
    }

    @RequestMapping(value="/getleaveapplication/{leaveId}")
    public LeaveRecords getLeaveApplication(@PathVariable Integer leaveId){
        LeaveRecords leave= leaveApplicationImpl.getLeaveApplication(leaveId);

        return leave;
    }

    @RequestMapping(value="/leavecancellation/{leaveId}")
    public String LeaveCancellation(@PathVariable Integer leaveId){
        leaveApplicationImpl.LeaveCancellation(leaveId);
        return "Leave Application Cancelled";
    }

    @RequestMapping(value="/getnumberoftotalleaves/{employeeId}")
    public Integer getNumberOfTotalLeaves(@PathVariable Integer employeeId){
        return leaveApplicationImpl.getNumberOfTotalLeaves(employeeId);
    }

    @RequestMapping(value="/getnumberofcasualleaves/{employeeId}")
    public Integer getNumberOfCasualLeaves(@PathVariable Integer employeeId){
        return leaveApplicationImpl.getNumberOfCasualLeaves(employeeId);
    }

    @RequestMapping(value="/getnumberofsickleaves/{employeeId}")
    public Integer getNumberOfSickLeaves(@PathVariable Integer employeeId){
        return leaveApplicationImpl.getNumberOfSickLeaves(employeeId);
    }

    @RequestMapping(value="/getnumberofotherleaves/{employeeId}")
    public Integer getNumberOfOtherLeaves(@PathVariable Integer employeeId){
        return leaveApplicationImpl.getNumberOfOtherLeaves(employeeId);
    }

    @RequestMapping(value="/getleavehistory/{employeeId}")
    public List<LeaveRecords> getLeaveHistory(@PathVariable Integer employeeId){
        return leaveApplicationImpl.getLeaveHistory(employeeId);
    }
}