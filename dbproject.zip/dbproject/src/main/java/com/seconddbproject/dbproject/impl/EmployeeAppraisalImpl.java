package com.seconddbproject.dbproject.impl;

import com.seconddbproject.dbproject.DTO.Response;
import com.seconddbproject.dbproject.model.EmployeeAppraisal;
import com.seconddbproject.dbproject.repository.EmployeeAppraisalInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeAppraisalImpl implements EmployeeAppraisalInterface {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public EmployeeAppraisal getEmployeeAppraisal(Integer employeeId) {
        String sql = "select * from employee_appraisal where emp_id=?";
        EmployeeAppraisal employeeAppraisal = jdbcTemplate.queryForObject(sql,
                new Object[]{employeeId},
                new BeanPropertyRowMapper<>(EmployeeAppraisal.class));
        return employeeAppraisal;
        //return new Response(201,employeeAppraisal);
    }

    @Override
    public long getEmployeeRating(Integer employeeId) {
        EmployeeAppraisal employeeAppraisal = getEmployeeAppraisal(employeeId);
        Double averageValueRating = (employeeAppraisal.getInterpersonalSkills() +
                                        employeeAppraisal.getDevelopment()+
                                        employeeAppraisal.getCodeOfConduct()+
                                        employeeAppraisal.getCommunicationSkills()+
                                        employeeAppraisal.getPersonality()+
                                        employeeAppraisal.getLeadership())/6.0;
        Double kraRating = (employeeAppraisal.getKra1Weightage()*employeeAppraisal.getKra1Status()+
                employeeAppraisal.getKra2Weightage()*employeeAppraisal.getKra2Status()+
                employeeAppraisal.getKra3Weightage()*employeeAppraisal.getKra3Status()+
                employeeAppraisal.getKra4Weightage()*employeeAppraisal.getKra4Status()-
                (5*employeeAppraisal.getNumberOfRedFlags()))/10.0;

        long employeeRating = Math.round((averageValueRating + kraRating)/4.0);

        return employeeRating;
        //return new Response(201,employeeRating);

    }
}
