package com.seconddbproject.dbproject.model;

import com.seconddbproject.dbproject.middleware.LeaveApplication;

import java.util.Date;

public class LeaveRecords extends LeaveApplication {
    public LeaveRecords() {
    }

    public LeaveRecords(Integer emp_id, Date leaveFrom, Date leaveTo,
                        String leaveReason, String leaveType) {
      super(emp_id,leaveFrom,leaveTo,leaveReason,leaveType);
    }

    Integer leave_id;
    Integer verifiedBy;
    Integer approvedBy;
    Integer status;

    public Integer getLeave_id() {
        return leave_id;
    }

    public void setLeave_id(Integer leave_id) {
        this.leave_id = leave_id;
    }

    public Integer getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(Integer verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public Integer getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(Integer approvedBy) {
        this.approvedBy = approvedBy;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
