package com.seconddbproject.dbproject.middleware;

import java.util.Date;

public class LeaveApplication {
    Integer emp_id;
    Date leaveFrom;
    Date leaveTo;
    String leaveReason;
    String leaveType;

    public LeaveApplication(){}
    public LeaveApplication(Integer emp_id, Date leaveFrom, Date leaveTo, String leaveReason, String leaveType) {
        this.emp_id = emp_id;
        this.leaveFrom = leaveFrom;
        this.leaveTo = leaveTo;
        this.leaveReason = leaveReason;
        this.leaveType = leaveType;
    }

    public Integer getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(Integer emp_id) {
        this.emp_id = emp_id;
    }

    public Date getLeaveFrom() {
        return leaveFrom;
    }

    public void setLeaveFrom(Date leaveFrom) {
        this.leaveFrom = leaveFrom;
    }

    public Date getLeaveTo() {
        return leaveTo;
    }

    public void setLeaveTo(Date leaveTo) {
        this.leaveTo = leaveTo;
    }

    public String getLeaveReason() {
        return leaveReason;
    }

    public void setLeaveReason(String leaveReason) {
        this.leaveReason = leaveReason;
    }

    public String getLeaveType() {
        return leaveType;
    }

    public void setLeaveType(String leaveType) {
        this.leaveType = leaveType;
    }
}
