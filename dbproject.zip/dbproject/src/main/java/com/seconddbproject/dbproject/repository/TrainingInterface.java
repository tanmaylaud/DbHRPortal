package com.seconddbproject.dbproject.repository;

import com.seconddbproject.dbproject.middleware.EnrolledCourses;
import com.seconddbproject.dbproject.model.EmployeeTraining;

import java.util.List;

public interface TrainingInterface {

    List<EnrolledCourses> getListOfCourses(Integer employeeId);

    List<EnrolledCourses> updateCourseStatus(Integer courseId , Integer employeeId);
}
