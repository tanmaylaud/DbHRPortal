package com.seconddbproject.dbproject.controller;

import com.seconddbproject.dbproject.DTO.Response;
import com.seconddbproject.dbproject.impl.LoginImpl;
import com.seconddbproject.dbproject.middleware.LoginDetails;
import com.seconddbproject.dbproject.model.LoginMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
public class LoginController {
    @Autowired
    LoginImpl loginImpl;

    @CrossOrigin(allowedHeaders = {"Origin","X-Requested-With","Content-Type","Accept","Authorization"},
    methods = {RequestMethod.GET,RequestMethod.DELETE,RequestMethod.POST,RequestMethod.PUT})

    @RequestMapping(value = "/login")
    Response login(@RequestBody LoginDetails loginDetails) {
        return loginImpl.login(loginDetails);
    }
}
