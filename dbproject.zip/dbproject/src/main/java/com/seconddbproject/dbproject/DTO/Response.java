package com.seconddbproject.dbproject.DTO;

public class Response {
    Integer responseStatus;
    Object object;

    public Response() {
    }

    public Response(Integer status, Object object) {
        this.responseStatus = status;
        this.object = object;
    }

    public Integer getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(Integer responseStatus) {
        this.responseStatus = responseStatus;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }
}
