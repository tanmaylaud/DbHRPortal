package com.seconddbproject.dbproject.impl;

import com.seconddbproject.dbproject.middleware.LeaveApplication;
import com.seconddbproject.dbproject.model.LeaveRecords;
import com.seconddbproject.dbproject.repository.LeaveApplicationInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;
import java.util.List;

@Repository
public class LeaveApplicationImpl implements LeaveApplicationInterface {

    @Autowired
    JdbcTemplate jdbcTemplate;


    @Override
    public void leaveRequest(LeaveApplication leaveApplication) {

        LeaveRecords leaveRecords = new LeaveRecords(leaveApplication.getEmp_id(),
                leaveApplication.getLeaveFrom(),
                leaveApplication.getLeaveTo(),
                leaveApplication.getLeaveReason(),
                leaveApplication.getLeaveType());


        String sql = "select manager_id from employee_master where emp_id = ?";
        Integer manager_id = jdbcTemplate.queryForObject(sql,new Object[]{leaveRecords.getEmp_id()},
                Integer.class);
        if(manager_id == 0)
        {
            leaveRecords.setStatus(0);
            leaveRecords.setVerifiedBy(leaveApplication.getEmp_id());
            leaveRecords.setApprovedBy(leaveApplication.getEmp_id());
        }
        else {
            leaveRecords.setVerifiedBy(manager_id);
            leaveRecords.setApprovedBy(manager_id);
            leaveRecords.setStatus(1);
        }

        String  query = "insert into leave_records values" +
                "(?,?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(query,
                new Object[]{0,leaveRecords.getEmp_id(),
                        leaveRecords.getLeaveFrom(),
                        leaveRecords.getLeaveTo(),
                        leaveRecords.getLeaveType(),
                        leaveRecords.getLeaveReason(),
                        leaveRecords.getVerifiedBy(),
                        leaveRecords.getApprovedBy(),
                        leaveRecords.getStatus()});

    }

    @Override
    public void leaveApproval(Integer leaveId) {

        String sql = "update leave_records set status = ? where leave_id = ?";

        LeaveRecords leave = getLeaveApplication(leaveId);

        long diff = leave.getLeaveTo().getTime() - leave.getLeaveFrom().getTime();
        Integer numberOfLeavesApplied  = (int)(diff/(1000*60*60*24));
        numberOfLeavesApplied +=1;
        if(leave.getLeaveType().equals("casual")){
            Integer availableCasualLeaves = 25-getNumberOfCasualLeaves(leave.getEmp_id());
            if(numberOfLeavesApplied <= availableCasualLeaves){
                updateLeaves("casual",leave.getEmp_id(),numberOfLeavesApplied);
            }
            else{
                updateLeaves("casual",leave.getEmp_id(),availableCasualLeaves);
                updateLeaves("other",leave.getEmp_id(),numberOfLeavesApplied-availableCasualLeaves);
            }
            jdbcTemplate.update(sql, new Object[]{0, leaveId},
                    new int[]{Types.VARCHAR,
                            Types.INTEGER});
        }
        if(leave.getLeaveType().equals("sick")){
            Integer availableSickLeaves = 12-getNumberOfSickLeaves(leave.getEmp_id());
            if(numberOfLeavesApplied <= availableSickLeaves){
                updateLeaves("sick",leave.getEmp_id(),numberOfLeavesApplied);
            }
            else{
                updateLeaves("sick",leave.getEmp_id(),availableSickLeaves);
                updateLeaves("other",leave.getEmp_id(),numberOfLeavesApplied-availableSickLeaves);
            }
            jdbcTemplate.update(sql, new Object[]{0, leaveId},
                    new int[]{Types.VARCHAR,
                            Types.INTEGER});
        }
        if(leave.getLeaveType().equals("other")){
            updateLeaves("other",leave.getEmp_id(),numberOfLeavesApplied);
            jdbcTemplate.update(sql, new Object[]{0, leaveId},
                    new int[]{Types.VARCHAR,
                            Types.INTEGER});
        }


    }

    @Override
    public void leaveRejection(Integer leaveId) {
        String sql = "update leave_records set status = ? where leave_id = ?";
        jdbcTemplate.update(sql, new Object[]{2, leaveId},
                new int[]{Types.VARCHAR,
                        Types.INTEGER});
    }

    @Override
    public List<LeaveRecords> getAllLeaveApplications(Integer managerId) {
        String sql = "select * from leave_records where approved_by=? and status=?";
        List<LeaveRecords> list = jdbcTemplate.query(sql,
                new Object[]{managerId,1},
                new BeanPropertyRowMapper(LeaveRecords.class));
        return list;
    }

    @Override
    public LeaveRecords getLeaveApplication(Integer leaveId) {
        String sql = "select * from leave_records where leave_id=?";
        return jdbcTemplate.queryForObject(sql,
                new Object[]{leaveId},
                new BeanPropertyRowMapper<>(LeaveRecords.class));

    }

    @Override
    public void LeaveCancellation(Integer leaveId) {
        String sql = "delete from leave_records where leave_id=?";
        jdbcTemplate.update(sql,
                new Object[]{leaveId},
                new int[]{Types.INTEGER});
    }

    @Override
    public Integer getNumberOfCasualLeaves(Integer employeeId) {
        String sql = "select casual_leave from employee_master where emp_id=?";
        return jdbcTemplate.queryForObject(sql,new Object[]{employeeId},Integer.class);

    }

    @Override
    public Integer getNumberOfSickLeaves(Integer employeeId) {
        String sql = "select sick_leave from employee_master where emp_id=?";
        return jdbcTemplate.queryForObject(sql,new Object[]{employeeId},Integer.class);
    }

    @Override
    public Integer getNumberOfTotalLeaves(Integer employeeId) {
        String sql = "select leave_consumed from employee_master where emp_id=?";
        return jdbcTemplate.queryForObject(sql,new Object[]{employeeId},Integer.class);
    }

    @Override
    public Integer getNumberOfOtherLeaves(Integer employeeId) {
        String sql = "select other_leave from employee_master where emp_id=?";
        return jdbcTemplate.queryForObject(sql,new Object[]{employeeId},Integer.class);
    }

    @Override
    public List<LeaveRecords> getLeaveHistory(Integer employeeId) {
        String sql = "select * from leave_records where emp_id=?";
        return jdbcTemplate.query(sql,
                new BeanPropertyRowMapper(LeaveRecords.class));
    }

    void updateLeaves(String leaveType, Integer employeeId, Integer numberOfLeaves){
        if(leaveType.equals("casual")){
            String sql = "update employee_master set casual_leave=? where emp_id=?";
            jdbcTemplate.update(sql,
                    new Object[]{getNumberOfCasualLeaves(employeeId)+numberOfLeaves,employeeId},
                    new int[]{Types.INTEGER,Types.INTEGER});

        }

        if(leaveType.equals("sick")){
            String sql = "update employee_master set sick_leave=? where emp_id=?";
            jdbcTemplate.update(sql,
                    new Object[]{getNumberOfSickLeaves(employeeId)+numberOfLeaves,employeeId},
                    new int[]{Types.INTEGER,Types.INTEGER});

        }

        if(leaveType.equals("other")){
            String sql = "update employee_master set other_leave=? where emp_id=?";
            jdbcTemplate.update(sql,
                    new Object[]{getNumberOfOtherLeaves(employeeId)+numberOfLeaves,employeeId},
                    new int[]{Types.INTEGER,Types.INTEGER});

        }

        String sql = "update employee_master set leave_consumed=? where emp_id=?";
        jdbcTemplate.update(sql,
                new Object[]{getNumberOfTotalLeaves(employeeId)+numberOfLeaves,employeeId},
                new int[]{Types.INTEGER,Types.INTEGER});
    }
}
