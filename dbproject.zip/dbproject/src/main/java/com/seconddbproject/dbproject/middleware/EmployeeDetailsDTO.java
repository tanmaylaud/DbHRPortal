package com.seconddbproject.dbproject.middleware;

import com.seconddbproject.dbproject.model.EmployeeMaster;

import java.util.Date;
import java.util.List;

public class EmployeeDetailsDTO extends EmployeeMaster {
    Boolean isManager;
    List<EmployeeMaster> employees;

    public EmployeeDetailsDTO() {
    }

    public EmployeeDetailsDTO(Integer emp_id, String first_name, String middle_name, String last_name, String gender, Date date_of_joining, Date date_of_birth, Integer division_id, Integer dept_id, String team, Integer manager_id, Integer leave_accumulated, Integer leave_consumed, String contact_no, String address, String aadhar, String pan, Integer sick_leave, Integer other_leave, Boolean isManager, List<EmployeeMaster> employees) {
        super(emp_id, first_name, middle_name, last_name, gender, date_of_joining, date_of_birth, division_id, dept_id, team, manager_id, leave_accumulated, leave_consumed, contact_no, address, aadhar, pan, sick_leave, other_leave);
        this.isManager = isManager;
        this.employees = employees;
    }

    public EmployeeDetailsDTO(EmployeeMaster employeeMaster,Boolean isManager,List<EmployeeMaster> employees){
        super(employeeMaster.getEmp_id(),employeeMaster.getFirst_name(),employeeMaster.getMiddle_name(),employeeMaster.getLast_name(),
                employeeMaster.getGender(),employeeMaster.getDate_of_joining(),employeeMaster.getDate_of_birth(),
                employeeMaster.getDivision_id(),employeeMaster.getDept_id(),employeeMaster.getTeam(),
                employeeMaster.getManager_id(),employeeMaster.getLeave_accumulated(),employeeMaster.getLeave_consumed(),
                employeeMaster.getContact_no(),employeeMaster.getAddress(),employeeMaster.getAadhar(),
                employeeMaster.getPan(),employeeMaster.getSick_leave(),employeeMaster.getOther_leave());
        this.isManager=isManager;
        this.employees=employees;
    }
    public Boolean getManager() {
        return isManager;
    }

    public void setManager(Boolean isManager) {
        this.isManager = isManager;
    }

    public List<EmployeeMaster> getEmployees() {
        return employees;
    }

    public void setEmployees(List<EmployeeMaster> employees) {
        this.employees = employees;
    }
}
