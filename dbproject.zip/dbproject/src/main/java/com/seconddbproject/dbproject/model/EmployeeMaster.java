package com.seconddbproject.dbproject.model;

import java.util.Date;

public class EmployeeMaster {
    Integer emp_id;
    String first_name;
    String middle_name;
    String last_name;
    String gender;
    Date date_of_joining;
    Date date_of_birth;
    Integer division_id;
    Integer dept_id;
    String team;
    Integer manager_id;
    Integer leave_accumulated;
    Integer leave_consumed;
    String contact_no;
    String address;
    String aadhar;
    String pan;
    Integer sick_leave;
    Integer other_leave;

    public EmployeeMaster() {
    }

    public EmployeeMaster(Integer emp_id, String first_name, String middle_name, String last_name, String gender, Date date_of_joining, Date date_of_birth, Integer division_id, Integer dept_id, String team, Integer manager_id, Integer leave_accumulated, Integer leave_consumed, String contact_no, String address, String aadhar, String pan, Integer sick_leave, Integer other_leave) {
        this.emp_id = emp_id;
        this.first_name = first_name;
        this.middle_name = middle_name;
        this.last_name = last_name;
        this.gender = gender;
        this.date_of_joining = date_of_joining;
        this.date_of_birth = date_of_birth;
        this.division_id = division_id;
        this.dept_id = dept_id;
        this.team = team;
        this.manager_id = manager_id;
        this.leave_accumulated = leave_accumulated;
        this.leave_consumed = leave_consumed;
        this.contact_no = contact_no;
        this.address = address;
        this.aadhar = aadhar;
        this.pan = pan;
        this.sick_leave = sick_leave;
        this.other_leave = other_leave;
    }

    public Integer getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(Integer emp_id) {
        this.emp_id = emp_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getMiddle_name() {
        return middle_name;
    }

    public void setMiddle_name(String middle_name) {
        this.middle_name = middle_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDate_of_joining() {
        return date_of_joining;
    }

    public void setDate_of_joining(Date date_of_joining) {
        this.date_of_joining = date_of_joining;
    }

    public Date getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(Date date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    public Integer getDivision_id() {
        return division_id;
    }

    public void setDivision_id(Integer division_id) {
        this.division_id = division_id;
    }

    public Integer getDept_id() {
        return dept_id;
    }

    public void setDept_id(Integer dept_id) {
        this.dept_id = dept_id;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public Integer getManager_id() {
        return manager_id;
    }

    public void setManager_id(Integer manager_id) {
        this.manager_id = manager_id;
    }

    public Integer getLeave_accumulated() {
        return leave_accumulated;
    }

    public void setLeave_accumulated(Integer leave_accumulated) {
        this.leave_accumulated = leave_accumulated;
    }

    public Integer getLeave_consumed() {
        return leave_consumed;
    }

    public void setLeave_consumed(Integer leave_consumed) {
        this.leave_consumed = leave_consumed;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAadhar() {
        return aadhar;
    }

    public void setAadhar(String aadhar) {
        this.aadhar = aadhar;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public Integer getSick_leave() {
        return sick_leave;
    }

    public void setSick_leave(Integer sick_leave) {
        this.sick_leave = sick_leave;
    }

    public Integer getOther_leave() {
        return other_leave;
    }

    public void setOther_leave(Integer other_leave) {
        this.other_leave = other_leave;
    }
}
