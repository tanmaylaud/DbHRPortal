package com.seconddbproject.dbproject.controller;

import com.seconddbproject.dbproject.DTO.Response;
import com.seconddbproject.dbproject.impl.EmployeeAppraisalImpl;
import com.seconddbproject.dbproject.model.EmployeeAppraisal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class EmployeeAppraisalController {
    @Autowired
    EmployeeAppraisalImpl employeeAppraisalImpl;

    @CrossOrigin(allowedHeaders = {"Origin","X-Requested-With","Content-Type","Accept","Authorization"},
     methods = {RequestMethod.GET,RequestMethod.DELETE,RequestMethod.POST,RequestMethod.PUT})

    @RequestMapping(value = "/getemployeeappraisal/{employeeId}")
    public EmployeeAppraisal getEmployeeAppraisal(@PathVariable  Integer employeeId){
        return employeeAppraisalImpl.getEmployeeAppraisal(employeeId);
    }

    @RequestMapping(value="/getemployeerating/{employeeId}")
    public long getEmployeeRating(@PathVariable Integer employeeId){
        return employeeAppraisalImpl.getEmployeeRating(employeeId);
    }



}
